Cassini++ Web Server for .NET v3.5 README.TXT
------------------------------------------

This Cassini++ version requires .NET Framework v3.5

This sample illustrates using the ASP.NET hosting APIs (System.Web.Hosting)
to create a simple managed Web Server with System.Net APIs.

Features:
* Single exe file. No need to install!
* Only 65K small!
* Running ASP.NET applications!
* Licensed under Ms-PL
* Can be run as private web server or public available web server (recommended only in secure envirnoments)
* Minimize to tray

Instructions to Run Cassini++
---------------------------

Cassinipp <physical-path> <port> <virtual-path> <loopback|any>

Examples:

Cassinipp c:\ 80 / 
Starts cassini with application directory "c:\" listening on port 80 on
loopback device (127.0.0.1 aka localhost)

Cassinipp c:\ 80 / any
Starts cassini with application directory "c:\" listening on port 80 on 
any ip adress (reachable from network) using virtual path "/"

Cassinipp c:\
Starts cassini with application directory "c:\" listening on port 80 of 
loopback device using virtual path "/"