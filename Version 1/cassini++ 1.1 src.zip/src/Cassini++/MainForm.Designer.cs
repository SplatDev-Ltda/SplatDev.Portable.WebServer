﻿namespace Cassinipp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.lblPort = new System.Windows.Forms.Label();
            this.lblAppPath = new System.Windows.Forms.Label();
            this.txtAppPath = new System.Windows.Forms.TextBox();
            this.fbDlgSelectAppPath = new System.Windows.Forms.FolderBrowserDialog();
            this.btnSelectDirectory = new System.Windows.Forms.Button();
            this.lblVirtRoot = new System.Windows.Forms.Label();
            this.txtVirtRoot = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.noiCassini = new System.Windows.Forms.NotifyIcon(this.components);
            this.cmsNotifyIcon = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.llaOpenBrowser = new System.Windows.Forms.LinkLabel();
            this.rdbLoopBack = new System.Windows.Forms.RadioButton();
            this.rdbAny = new System.Windows.Forms.RadioButton();
            this.gboAddress = new System.Windows.Forms.GroupBox();
            this.ssStatus = new System.Windows.Forms.StatusStrip();
            this.tssStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.nudPort = new System.Windows.Forms.NumericUpDown();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.btnAbout = new System.Windows.Forms.Button();
            this.lblLogo = new System.Windows.Forms.Label();
            this.cmsNotifyIcon.SuspendLayout();
            this.gboAddress.SuspendLayout();
            this.ssStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPort)).BeginInit();
            this.pnlLogo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPort
            // 
            this.lblPort.AutoSize = true;
            this.lblPort.Location = new System.Drawing.Point(12, 87);
            this.lblPort.Name = "lblPort";
            this.lblPort.Size = new System.Drawing.Size(63, 13);
            this.lblPort.TabIndex = 1;
            this.lblPort.Text = "Server Port:";
            // 
            // lblAppPath
            // 
            this.lblAppPath.AutoSize = true;
            this.lblAppPath.Location = new System.Drawing.Point(12, 64);
            this.lblAppPath.Name = "lblAppPath";
            this.lblAppPath.Size = new System.Drawing.Size(87, 13);
            this.lblAppPath.TabIndex = 3;
            this.lblAppPath.Text = "Application Path:";
            // 
            // txtAppPath
            // 
            this.txtAppPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAppPath.Location = new System.Drawing.Point(99, 61);
            this.txtAppPath.Name = "txtAppPath";
            this.txtAppPath.Size = new System.Drawing.Size(294, 20);
            this.txtAppPath.TabIndex = 1;
            this.txtAppPath.TextChanged += new System.EventHandler(this.txtAppPath_TextChanged);
            // 
            // btnSelectDirectory
            // 
            this.btnSelectDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectDirectory.Location = new System.Drawing.Point(399, 59);
            this.btnSelectDirectory.Name = "btnSelectDirectory";
            this.btnSelectDirectory.Size = new System.Drawing.Size(25, 23);
            this.btnSelectDirectory.TabIndex = 2;
            this.btnSelectDirectory.Text = "...";
            this.btnSelectDirectory.UseVisualStyleBackColor = true;
            this.btnSelectDirectory.Click += new System.EventHandler(this.btnSelectDirectory_Click);
            // 
            // lblVirtRoot
            // 
            this.lblVirtRoot.AutoSize = true;
            this.lblVirtRoot.Location = new System.Drawing.Point(12, 114);
            this.lblVirtRoot.Name = "lblVirtRoot";
            this.lblVirtRoot.Size = new System.Drawing.Size(65, 13);
            this.lblVirtRoot.TabIndex = 6;
            this.lblVirtRoot.Text = "Virtual Root:";
            // 
            // txtVirtRoot
            // 
            this.txtVirtRoot.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtVirtRoot.Location = new System.Drawing.Point(99, 111);
            this.txtVirtRoot.Name = "txtVirtRoot";
            this.txtVirtRoot.Size = new System.Drawing.Size(197, 20);
            this.txtVirtRoot.TabIndex = 4;
            this.txtVirtRoot.Text = "/";
            this.txtVirtRoot.TextChanged += new System.EventHandler(this.txtVirtRoot_TextChanged);
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.Location = new System.Drawing.Point(318, 147);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 7;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(318, 176);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 8;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // noiCassini
            // 
            this.noiCassini.ContextMenuStrip = this.cmsNotifyIcon;
            this.noiCassini.Icon = ((System.Drawing.Icon)(resources.GetObject("noiCassini.Icon")));
            this.noiCassini.Text = "Cassini++";
            this.noiCassini.DoubleClick += new System.EventHandler(this.noiCassini_DoubleClick);
            // 
            // cmsNotifyIcon
            // 
            this.cmsNotifyIcon.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem,
            this.stopToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.cmsNotifyIcon.Name = "cmsNotifyIcon";
            this.cmsNotifyIcon.Size = new System.Drawing.Size(110, 70);
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.startToolStripMenuItem.Text = "Start";
            this.startToolStripMenuItem.Click += new System.EventHandler(this.startToolStripMenuItem_Click);
            // 
            // stopToolStripMenuItem
            // 
            this.stopToolStripMenuItem.Enabled = false;
            this.stopToolStripMenuItem.Name = "stopToolStripMenuItem";
            this.stopToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.stopToolStripMenuItem.Text = "Stop";
            this.stopToolStripMenuItem.Click += new System.EventHandler(this.stopToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // llaOpenBrowser
            // 
            this.llaOpenBrowser.AutoSize = true;
            this.llaOpenBrowser.Location = new System.Drawing.Point(96, 205);
            this.llaOpenBrowser.MinimumSize = new System.Drawing.Size(84, 13);
            this.llaOpenBrowser.Name = "llaOpenBrowser";
            this.llaOpenBrowser.Size = new System.Drawing.Size(84, 13);
            this.llaOpenBrowser.TabIndex = 11;
            this.llaOpenBrowser.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llaOpenBrowser_LinkClicked);
            // 
            // rdbLoopBack
            // 
            this.rdbLoopBack.AutoSize = true;
            this.rdbLoopBack.Checked = true;
            this.rdbLoopBack.Location = new System.Drawing.Point(6, 19);
            this.rdbLoopBack.Name = "rdbLoopBack";
            this.rdbLoopBack.Size = new System.Drawing.Size(73, 17);
            this.rdbLoopBack.TabIndex = 5;
            this.rdbLoopBack.TabStop = true;
            this.rdbLoopBack.Text = "Loopback";
            this.rdbLoopBack.UseVisualStyleBackColor = true;
            // 
            // rdbAny
            // 
            this.rdbAny.AutoSize = true;
            this.rdbAny.Location = new System.Drawing.Point(6, 42);
            this.rdbAny.Name = "rdbAny";
            this.rdbAny.Size = new System.Drawing.Size(43, 17);
            this.rdbAny.TabIndex = 6;
            this.rdbAny.Text = "Any";
            this.rdbAny.UseVisualStyleBackColor = true;
            // 
            // gboAddress
            // 
            this.gboAddress.Controls.Add(this.rdbLoopBack);
            this.gboAddress.Controls.Add(this.rdbAny);
            this.gboAddress.Location = new System.Drawing.Point(99, 137);
            this.gboAddress.Name = "gboAddress";
            this.gboAddress.Size = new System.Drawing.Size(197, 65);
            this.gboAddress.TabIndex = 14;
            this.gboAddress.TabStop = false;
            this.gboAddress.Text = "Listen on";
            // 
            // ssStatus
            // 
            this.ssStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tssStatus});
            this.ssStatus.Location = new System.Drawing.Point(0, 225);
            this.ssStatus.MinimumSize = new System.Drawing.Size(300, 0);
            this.ssStatus.Name = "ssStatus";
            this.ssStatus.Size = new System.Drawing.Size(436, 22);
            this.ssStatus.TabIndex = 16;
            this.ssStatus.Text = "statusStrip1";
            // 
            // tssStatus
            // 
            this.tssStatus.Name = "tssStatus";
            this.tssStatus.Overflow = System.Windows.Forms.ToolStripItemOverflow.Always;
            this.tssStatus.Size = new System.Drawing.Size(0, 17);
            // 
            // nudPort
            // 
            this.nudPort.Location = new System.Drawing.Point(99, 85);
            this.nudPort.Maximum = new decimal(new int[] {
            64000,
            0,
            0,
            0});
            this.nudPort.Name = "nudPort";
            this.nudPort.Size = new System.Drawing.Size(79, 20);
            this.nudPort.TabIndex = 3;
            this.nudPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudPort.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            this.nudPort.ValueChanged += new System.EventHandler(this.nudPort_ValueChanged);
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.SystemColors.Window;
            this.pnlLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLogo.Controls.Add(this.btnAbout);
            this.pnlLogo.Controls.Add(this.lblLogo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(436, 37);
            this.pnlLogo.TabIndex = 18;
            // 
            // btnAbout
            // 
            this.btnAbout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAbout.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAbout.FlatAppearance.BorderSize = 0;
            this.btnAbout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnAbout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Image = ((System.Drawing.Image)(resources.GetObject("btnAbout.Image")));
            this.btnAbout.Location = new System.Drawing.Point(398, 5);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(25, 23);
            this.btnAbout.TabIndex = 1;
            this.btnAbout.UseVisualStyleBackColor = true;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // lblLogo
            // 
            this.lblLogo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLogo.AutoSize = true;
            this.lblLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblLogo.Location = new System.Drawing.Point(10, 8);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(87, 20);
            this.lblLogo.TabIndex = 0;
            this.lblLogo.Text = "Cassini++";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 247);
            this.Controls.Add(this.pnlLogo);
            this.Controls.Add(this.gboAddress);
            this.Controls.Add(this.llaOpenBrowser);
            this.Controls.Add(this.nudPort);
            this.Controls.Add(this.txtVirtRoot);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.lblVirtRoot);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.txtAppPath);
            this.Controls.Add(this.lblPort);
            this.Controls.Add(this.btnSelectDirectory);
            this.Controls.Add(this.lblAppPath);
            this.Controls.Add(this.ssStatus);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(444, 281);
            this.Name = "MainForm";
            this.Text = "Cassini++";
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.cmsNotifyIcon.ResumeLayout(false);
            this.gboAddress.ResumeLayout(false);
            this.gboAddress.PerformLayout();
            this.ssStatus.ResumeLayout(false);
            this.ssStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPort)).EndInit();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPort;
        private System.Windows.Forms.Label lblAppPath;
        private System.Windows.Forms.TextBox txtAppPath;
        private System.Windows.Forms.FolderBrowserDialog fbDlgSelectAppPath;
        private System.Windows.Forms.Button btnSelectDirectory;
        private System.Windows.Forms.Label lblVirtRoot;
        private System.Windows.Forms.TextBox txtVirtRoot;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.NotifyIcon noiCassini;
        private System.Windows.Forms.LinkLabel llaOpenBrowser;
        private System.Windows.Forms.RadioButton rdbLoopBack;
        private System.Windows.Forms.RadioButton rdbAny;
        private System.Windows.Forms.GroupBox gboAddress;
        private System.Windows.Forms.ContextMenuStrip cmsNotifyIcon;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.StatusStrip ssStatus;
        private System.Windows.Forms.ToolStripStatusLabel tssStatus;
        private System.Windows.Forms.NumericUpDown nudPort;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Button btnAbout;
    }
}